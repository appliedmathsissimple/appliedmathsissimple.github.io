---
layout: post
comments: true
categories: paracraft
---

## Empty diary template

Empty post template